import React from 'react'
import Coat from './Images/coat.png'
import { useState } from 'react'
export default function ShopPg42() {
  const [count, setcount] = useState(0)
  const increment = () => {
    setcount(count + 1)

  }
  const decrement = () => {
    if (count > 1) {
      setcount(count - 1)

    }
    else setcount(0)

  }
  return (
    <div>
      <div className="container">
        <div className="row">
          <div className="col-lg-6 ">
            <div className="container">
              <h2>Shop</h2>
              <div className="row p-2" style={{ position: "relative", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>
                <div className="col-lg-4 col-sm-4  ">
                  <img className=' ' style={{ height: "190px" }} src={Coat} alt="" />
                </div>
                <div className="col-lg-5 col-sm-5" style={{ borderRight: "1px solid lightgrey" }}>
                  <div style={{ lineHeight: "4px" }}>
                    <h5>Black Gold Coat</h5>
                    <p style={{ color: "grey", fontSize: "13px" }}>By Al-Karim</p>
                  </div>
                  <p style={{ color: "#244e78" }}><b>In Stock</b></p>
                  <div className='d-flex' >
                    <p style={{ color: "grey", fontSize: "" }}>Qty: </p>
                    <p style={{ border: "1px solid lightgrey", padding: "3px 10px", cursor: "pointer", marginLeft: "10px" }} onClick={() => decrement()}>-</p>
                    <p style={{ border: "1px solid lightgrey", padding: "5px 15px", cursor: "pointer" }}  >{count}</p>
                    <p style={{ border: "1px solid lightgrey", padding: "3px 10px", cursor: "pointer" }} onClick={() => increment()}>+</p>
                  </div>
                  <div style={{ lineHeight: "4px", marginTop: "15px" }}>
                    <p style={{ color: "grey", fontSize: "13px" }}> Delivery by Sat,Mar 22</p>
                    <p style={{ color: "#244e78", fontSize: "13px" }}>6% off 3 offers Available</p>
                  </div>
                </div>
                <div className="col-lg-3 col-sm-3 mt-2" style={{ textAlign: "center", lineHeight: "12px" }}>
                  <p style={{ marginTop: "10px" }}><b>Rs, 1500</b></p><br /><span style={{ fontSize: "13px", padding: "", color: "#244e78", backgroundColor: "lightblue" }}> Free Shipping</span>
                  <div>
                    <button type="button" className="btn " style={{ width: "100px", marginTop: "15px", backgroundColor: "white", color: "black", border: "1px solid grey" }}> <b>Remove</b> </button>
                    <button type="button" className="btn " style={{ width: "100px", marginTop: "10px", backgroundColor: "#244e78", color: "white" }}>Wishlist</button>
                  </div>
                </div>
              </div>
              <div className="row p-2 mt-5" style={{ position: "relative", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>
                <div className="col-lg-4 col-sm-4  ">
                  <img className=' ' style={{ height: "190px" }} src={Coat} alt="" />
                </div>
                <div className="col-lg-5 col-sm-5" style={{ borderRight: "1px solid lightgrey" }}>
                  <div style={{ lineHeight: "4px" }}>
                    <h5>Black Gold Coat</h5>
                    <p style={{ color: "grey", fontSize: "13px" }}>By Al-Karim</p>
                  </div>
                  <p style={{ color: "#244e78" }}><b>In Stock</b></p>
                  <div className='d-flex' >
                    <p style={{ color: "grey", fontSize: "" }}>Qty: </p>
                    <p style={{ border: "1px solid lightgrey", padding: "3px 10px", cursor: "pointer", marginLeft: "10px" }} onClick={() => decrement()}>-</p>
                    <p style={{ border: "1px solid lightgrey", padding: "5px 15px", cursor: "pointer" }}  >{count}</p>
                    <p style={{ border: "1px solid lightgrey", padding: "3px 10px", cursor: "pointer" }} onClick={() => increment()}>+</p>
                  </div>
                  <div style={{ lineHeight: "4px", marginTop: "15px" }}>
                    <p style={{ color: "grey", fontSize: "13px" }}> Delivery by Sat,Mar 22</p>
                    <p style={{ color: "#244e78", fontSize: "13px" }}>6% off 3 offers Available</p>
                  </div>
                </div>
                <div className="col-lg-3 col-sm-3 mt-2" style={{ textAlign: "center", lineHeight: "12px" }}>
                  <p style={{ marginTop: "10px" }}><b>Rs, 1500</b></p><br /><span style={{ fontSize: "13px", padding: "", color: "#244e78", backgroundColor: "lightblue" }}> Free Shipping</span>
                  <div>
                    <button type="button" className="btn " style={{ width: "100px", marginTop: "15px", backgroundColor: "white", color: "black", border: "1px solid grey" }}> <b>Remove</b> </button>
                    <button type="button" className="btn " style={{ width: "100px", marginTop: "10px", backgroundColor: "#244e78", color: "white" }}>Wishlist</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-xl-2 col-sm-12 mt-5" style={{ position: "relative", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>
            <p>Options</p>
            <div style={{ borderBottom: "1px solid lightgrey" }}>
              <p ><b>Coupans </b><span style={{ float: "right", color: "#244e78", fontSize: "13px" }}>Apply</span></p>
              <p style={{ fontSize: "13px" }}><b>Price Details</b></p>
            </div>
            <div style={{color:"grey"}}>
              <p >Total MRP<span style={{ float: "right" }}>2000</span></p>
              <p >Bag Discount<span style={{ float: "right", color: "#244e78" }}>-700</span></p>
              <p >Estimaed Tax<span style={{ float: "right" }}>200</span></p>
              <p >EMI Eligibility<span style={{ float: "right" }}>Details</span></p>
              <p style={{ borderBottom: "1px solid lightgrey" }}  >Delivery Charges<span style={{ float: "right", color: "#244e78" }}>Free</span></p>
            </div>
            <p><b>Total <span style={{float:"right"}}>Rs.1500</span></b></p>
            <button type="button" className="btn " style={{ width: "100%", marginTop: "10px", backgroundColor: "#244e78", color: "white" }}>Place Order</button>

          </div>

        </div>
      </div>
    </div>
  )
}
