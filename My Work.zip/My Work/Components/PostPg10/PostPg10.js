import React from 'react'
import Gi from '../Components/girl.jpg'
import Postimg from '../Components/postimg.jpg'


const Test = () => {
  return (
    <div>


      <div className="container-posts">
        <div className="row">
          <div className="col-2"></div>
          <div className="col-3"></div>
          <div className="col-6 " style={{ fontSize: "14px" }} >
            <h2 >Posts</h2>
            <div className="postsdata mt-3" style={{ boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px" }}>
              <div className="context " style={{ paddingLeft: '20px', paddingTop: "5px" }}>
                <div className="DenJohn d-flex pt-3" >
                  <img style={{ borderRadius: "50%", height: "50px", width: "50px" }} src={Gi} alt="" />
                  <p style={{ fontWeight: '600', marginLeft: "10px" }}>Den John . <span style={{ color: "blue", cursor: "pointer" }}>Follow</span> <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></p>

                </div>
                <div className="bestlawyer " >
                  <p><b>How can you be a best lawyer in the world<br /></b>
                    In the very first challenge of the cryptocurrency,the Lahore High court has summoned the State Bank, SECP,<br />finance ministry and FIA to explain what step we have </p>
                </div>
              </div>
              <div className="post-Img">
                <img style={{ height: "3%", width: "100%" }} src={Postimg} alt="" />

              </div>
              <div className="bottom d-flex">
                <span><i class="bi bi-chat" style={{ paddingLeft: "20px", marginRight: "5px", cursor: "pointer" }}></i></span>
                <p>203</p>
                <i class="bi bi-three-dots" style={{ cursor: "pointer", marginLeft: "85%" }}></i>
              </div>
            </div>
          </div>
        </div>


      </div>

    </div>
  )
}
export default Test
