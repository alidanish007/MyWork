

import React, { useState } from 'react'
export default function SideBarPg36(props) {

    const [mybool, setbool] = useState(false)

    return (
        <div>
            <div className="container " >
                <div className="row " >
                    <div className="col-md-3 col-12 px-0" style={{ border: "1px solid lightgrey", overflowX: "hidden", marginRight: "20px" }}>
                        <div className='p-2' style={{ borderBottom: "1px solid lightgrey" }}>
                            <p style={{ display: "block", margin: "0" }}><b>Filter Result</b> <span style={{ float: "right" }}> <i onClick={() => setbool(!mybool)} class="bi bi-list"></i> </span></p>
                        </div>
                        <div className='p-2'>
                            {
                                mybool &&
                                <>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Types of Appointment</b></h7>
                                    <p></p><p>
                                        <input type="radio" name='gender' className='mx-3' /><span >In Clinic / Coat</span><br />
                                        <input type="radio" name='gender' className='mx-3' /><span>Video / Audio Call</span>
                                    </p>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Specialist Lawyer</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Acupuncture</option>
                                    </select>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>City</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Lahore</option>
                                    </select>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Area</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Choose Area</option>
                                    </select>
                                    <br /><p></p>
                                    <input type="checkbox" className='mx-3' /> Near Me
                                    <br />
                                    <input type="checkbox" className='mx-3' /> Discount
                                    <p></p>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Free Range</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Free Range</option>
                                    </select>
                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Availability</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Availability</option>
                                    </select>

                                    <h7 style={{ display: "block", marginLeft: "12px" }}><b>Gender</b></h7>
                                    <select name="" id="" className='m-3' style={{ width: "200px" }}>
                                        <option value=""> Gender</option>
                                    </select>
                                </>

                            }


                        </div>
                    </div>
                    <div className="col-12 col-md-8">
                        {props.component}
                    </div>
                </div>
            </div>
        </div>
    )
}
