//to render page 36 ->  <SideBarPg36 component={<OnlineConsultPg36/>}/>

import React from 'react'
import Gi from '../OnlineConsultPage36/girl.jpg'
import './Pg36.css'

import SideBarPg36 from './SideBarPg36'
export default function OnlineConsultPg36() {
    return (
       <>
                <div className="coloricon">
                    <div className="row " id='pg36'   style={{ border:"1px solid lightgrey" }}>
                        <div className="col-12 col-md-6  mt-3 " style={{ fontSize: "14px", paddingLeft: '20px', paddingTop: "5px" }} >
                            <div className="DenJohn d-flex pt-3"  >
                                <img style={{ borderRadius: "50%", height: "70px", width: "70px" }} src={Gi} alt="" />
                                <p style={{ fontWeight: '600', marginLeft: "10px" }}> <b><u> Den John </u></b>  <br /><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i><i class="bi bi-star"></i> <b>50 Reviews</b> <br />Dip. Acupuncture,Bsc, MS Acupuncture (London) <br />Member British Acupunctur... <br />15 year(s) Experience <br /> <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i><i class="bi bi-star"></i>
                                    <br /><i class="bi bi-patch-check-fill"></i> Verified
                                </p>
                            </div>
                            <div className="padding_problem" style={{paddingLeft:''}}>
                                <div className=" flex-column  d-flex flex-md-row">
                                    <div className="col-12 col-md-5 "><i class="bi bi-hand-thumbs-up-fill"></i><span style={{ }}>
                                        Satisfaction</span> <span style={{ textAlign: "center" }}> <b>97%</b> </span> </div>
                                    <div className="col-12 col-md-5 "><i class="bi bi-award-fill"></i><span style={{  }}>
                                        Experience</span> <span style={{ textAlign: "center" }}> <b>15 Year(s)</b> </span> </div>
                                    <div className="col-12 col-md-5 "><i class="bi bi-power"></i><span style={{  }}>
                                        Wait time</span> <span style={{ textAlign: "center" }}> <b>20 min</b> </span>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div className="col-6 text-end">
                            <div>
                                <button type="button" className="btn" style={{ width: "150px", marginTop: "13%", backgroundColor: "#244e78", color: "white" }}>Consult Online</button>
                            </div>
                            <div>
                                <button type="button" className="btn" style={{ width: "150px", marginTop: "5px", backgroundColor: "white", color: "#244e78", border: "1px solid grey" }}>Hire a Lawyer</button>
                            </div>
                        </div>
                        <div className="row d-flex  justify-content-center mb-2">
                            <div className="col-12 col-md-5  rounded" style={{ border: "1px solid lightgrey",}}>
                                <i class="bi bi-camera-video-fill"></i><span><b>Video Consultent</b></span><br />Audio/video <br /><b>Fee:</b><span style={{ textDecorationLine: "Line-Through" }}>Rs.5,000</span><span style={{ color: "#244e78", marginLeft: "5px" }}>Rs.3,000</span>
                                <p><b>Days:</b>Mon,Tue,Wed,Thurs,Fri,Sat,Sun <br /><b>Timing:</b> 12:00 pm - 8-00 pm</p>
                                <button type="button" className="btn mb-2" style={{ backgroundColor: "white", color: "#244e78" ,fontWeight:"bold" ,border:"2px solid #244e78",width:"100%",height:"20%"}}>Consult Online</button>
                            </div>
                        </div>
                    </div>
                </div>

        </>

    )
}


