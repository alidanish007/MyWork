import React from 'react'
import './Edit.css'

export default function Edit() {
    return (
        <div>
            <div className="edit p-1" style={{ position: "absolute" }}>

                <div className="e1" style={{ borderBottom: "1px solid lightgrey" }}>
                    <i class="bi bi-pencil-fill text-primary"></i>
                    <span >Edit </span>
                </div>
                <div className="e2">
                    <i class="bi bi-eye-fill text-primary"></i>
                    <span >View</span>
                    <span className='play'><i class="bi bi-play-fill"></i></span>
                </div>
            </div>
        </div>
    )
}
