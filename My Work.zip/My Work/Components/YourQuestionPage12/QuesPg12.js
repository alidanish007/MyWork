import React, { useState } from 'react'
import './QuesPg12.css'
import Edit from './Edit'
export default function QuesPg12() {
    const [mybool,setbool]=useState(false)
    const [mybool2,setbool2]=useState(false)
    return (
        <div>
            <div className="container">
                <div className="row ">
                    <div className="col-2 "> </div>
                    <div className="col-3"></div>
                    {/* here */}

                    <div className="col-7 ">

                        <h2 >Your Questions</h2>
                        <div className="questions row">
                            <div className=" q1 mt-2 col-md-5 p-0" style={{ marginRight: "30px" }}>
                                <div className="data" style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",position:"relative" }}>
                                    {
                                        mybool&&
                                        <Edit /> 
                                    }
                                    <span onClick={()=>setbool(!mybool)}><i class="bi bi-three-dots-vertical dots" style={{cursor:"pointer"}}></i></span>
                                    <p>In the first challenge of the cryptocurrency, the Lahore High court has summoned the State Bank, SECP,finance ministry and FIA to explain what step have?  </p>
                                </div>
                            </div>
                            {/* <div className="col-1"></div> */}
                            <div className=" q2  mt-2 col-md-5 p-0" >
                                <div className="data" style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" ,position:"relative"}}>
                                     {
                                        mybool2&&
                                        <Edit /> 
                                    }
                                    <span onClick={()=>setbool2(!mybool2)}><i class="bi bi-three-dots-vertical dots " style={{cursor:"pointer"}}></i></span>
                                    <p>In the first challenge of the cryptocurrency, the Lahore High court has summoned the State Bank, SECP,finance ministry and FIA to explain what step have?  </p>
                                </div>
                            </div>
                        </div>

                    </div>



                </div>
            </div>
        </div>
    )
}
