import React from 'react'
import './Pg40.css'

export default function ConfirmBookingPg40() {

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className=" col-md-3 col-10">
                        <h2 >Confirm Booking</h2>
                        <p style={{ marginTop: "20px" }}><b> Your Selected Schedule </b> <br /></p>
                        <div style={{ marginLeft: "40px" }}>
                            <span > <b>Tues,25 Jun -Wed 18 Jul</b>  <br /> 9:00 Am - 5:00 Pm </span>
                        </div>
                        <div className='mb-2'>
                            <br />
                            <p><b> Booking for</b></p>
                            <br />
                        </div>
                        <p><b>Price Details</b></p>


                        <div className="row p-2" style={{ backgroundColor: "skyblue" }}>
                            <div className="col-12">
                                <div className="row " style={{borderBottom:"1px solid black"}}>
                                    <div className="col-6 px-0">
                                        <p className='d-block m-0'>Price</p>
                                    </div>
                                    <div className="col-6 px-0">
                                        <p className='d-block m-0' style={{ textAlign: 'right' }}>1,500</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="row">
                                    <div className="col-6 px-0">
                                        <p className='d-block m-0'>Price</p>
                                    </div>
                                    <div className="col-6 px-0">
                                        <p className='d-block m-0' style={{ textAlign: 'right' }}>1,500</p>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div className='d-flex mt-2'>
                            <button type="button" className="btn" style={{ width: "100px", marginTop: "", backgroundColor: "white", color: "black", border: "1px solid grey" }}> <b>Back</b> </button>

                            <button type="button" className="btn" style={{ width: "280px", marginLeft: "5px", backgroundColor: "#244e78", color: "white" }}>Continue Booking</button>
                        </div>

                    </div>
                    <div className="col-md-4 col-10" style={{ marginLeft:"10px", padding: "20px", marginTop: "50px", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>
                        <div className="row">
                            <div style={{ padding: "5px", backgroundColor: "red", height: "60px", width: "70px" }} className="col-4">

                            </div>
                            <div className="col-8">
                                <p style={{ lineHeight: "20px" }} ><b >Ffff</b> <br />org <br /> <span style={{ fontSize: "small", lineHeight: "16px" }}> Sialkot,International Airpot <br />Road, Sialkot, Pakistan.</span> </p>
                            </div>

                            <div style={{ borderBottom: "1px solid lightgrey" }}></div>
                            <div style={{ marginLeft: "40px", marginTop: "10px" }}>
                                <span > <b>Tues,25 Jun -Wed 18 Jul</b>  <br /> 9:00 Am - 5:00 Pm </span>
                            </div>
                            <div>
                                <p>Description <br />fff <br /> <b>Rs. 1,500</b> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
