import React from 'react'
import './Pg20.css'
export default function DairyPg20() {
    return (
        <div>
            <div className="container">
                <div className="row ">
                    <div className="col-2 "> </div>
                    <div className="col-3"></div>
                    {/* here */}
                    <div className="col-7 ">
                        <h2 >Dairy</h2>
                        <div className="Dairy row ">
                            <div className="a">
                                <div style={{ backgroundColor: "#d8e8ff", border: "1px solid white", textAlign: "center" }}>
                                    <h4>Dairy Overview</h4>
                                    <ul className='row' style={{ backgroundColor: "white", listStyle: "none", display: "flex", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", width: "95%", marginLeft: "2%", marginBottom: "5%" }}>
                                        <div className='col-md-12'>
                                            <div className="row ">
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{ color: "blue", fontSize: "25px", }}>2</span><br /><p>Total Cases</p></li>
                                                </div>
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{ color: "orange", fontSize: "25px", }}>1</span><br /><p>Cases Fixed<br />Today</p></li>
                                                </div>
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{ color: "green", fontSize: "25px", }}>1</span><br /><p>Cases Fixed<br />Tomorrow</p></li>
                                                </div>
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{ color: "#14e78", fontSize: "25px", }}>0</span><br /><p>Open/Closed<br /> Cases</p></li>
                                                </div>
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{ color: "red", fontSize: "25px", }}>3</span><br /><p>Clients</p></li>
                                                </div>
                                                <div className="col-md-2 col-sm-6 col-12">
                                                    <li className=''><span style={{fontSize: "25px"}}><i class="bi bi-gear-fill"></i></span><br /><p>Settings</p></li>
                                                </div>
                                            </div>
                                        </div>
                                    </ul>
                                </div>

                            </div>
                        </div>
                        <div style={{marginTop:"5%", textAlign: "center" }}>
                            <h2>Setting</h2>
                            <button type="button" className="btn" style={{marginTop:"5%",backgroundColor:"#244e78",color:"white"}}>Share Your Diary</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}
