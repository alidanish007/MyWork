import React from 'react'
import Cards from './Images/VisaCard.png'
import Visa from './Images/Visa.png'
export default function PayPg41() {
    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-md-3 col-10">
                        <h2 >Payment</h2>

                        <div style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", padding: "10px", marginTop: "20px" }}>
                            <img style={{ height: "30px", width: "30px" }} src={Cards} alt="" />
                            <span style={{ paddingLeft: "8px" }}>Cards</span> <i style={{ color: "skyblue", float: "right" }} class="bi  bi-check-circle-fill"></i>
                        </div>
                        <div style={{ backgroundColor: "wheat", marginTop: "30px" }}>
                            <p><img style={{ height: "15px", width: "35px" }} src={Visa} alt="" /> <span>123456789</span></p>
                        </div>
                        <div className=' text-center mt-5'>
                            <button type="button" className="btn mx-3" style={{ width: "80px", marginTop: "", backgroundColor: "white", color: "black", border: "1px solid grey" }}> <b>Back</b> </button>

                            <button type="button" className="btn mx-3" style={{ width: "80px", marginLeft: "5px", backgroundColor: "#244e78", color: "white" }}>Next</button>
                        </div>

                    </div>
                    <div className="col-md-4 col-10" style={{ padding: "20px", marginTop: "50px", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>
                        <div className="row">
                            <div style={{ padding: "5px", backgroundColor: "red", height: "60px", width: "70px" }} className="col-4">

                            </div>
                            <div className="col-8">
                                <p style={{ lineHeight: "20px" }} ><b >Ffff</b> <br />org <br /> <span style={{ fontSize: "small", lineHeight: "16px" }}> Sialkot,International Airpot <br />Road, Sialkot, Pakistan.</span> </p>
                            </div>

                            <div style={{ borderBottom: "1px solid lightgrey" }}></div>
                            <div style={{ marginLeft: "40px", marginTop: "10px" }}>
                                <span > <b>Tues,25 Jun -Wed 18 Jul</b>  <br /> 9:00 Am - 5:00 Pm </span>
                            </div>
                            <div>
                                <p><b>Booking For</b></p>

                            </div>
                            <div className="row ms-5">
                                <div style={{ padding: "5px", backgroundColor: "yellow", height: "30px", width: "70px" }} className="col-4">

                                </div>
                                <div className="col-4">
                                    <p>Ass</p>
                                </div>

                            </div>
                            <div className="row ms-5">
                                <div style={{ padding: "5px", backgroundColor: "yellow", height: "30px", width: "70px" }} className="col-4">

                                </div>
                                <div className="col-4">
                                    <p>Ssg</p>
                                </div>

                            </div>
                            <div className="row p-2 mx-1" style={{ backgroundColor: "skyblue" }}>
                                <div className="col-12">
                                    <div className="row " style={{ borderBottom: "1px solid black" }}>
                                        <div className="col-6 px-0">
                                            <p className='d-block m-0'>Price</p>
                                        </div>
                                        <div className="col-6 px-0">
                                            <p className='d-block m-0' style={{ textAlign: 'right' }}>1,500</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="row">
                                        <div className="col-6 px-0">
                                            <p className='d-block m-0'>Price</p>
                                        </div>
                                        <div className="col-6 px-0">
                                            <p className='d-block m-0' style={{ textAlign: 'right' }}>1,500</p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
